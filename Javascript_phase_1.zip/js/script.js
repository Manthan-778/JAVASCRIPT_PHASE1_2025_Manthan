$(document).ready(function () {
    const $taskList = $("#task-list");
    const $filterTasks = $("#filter-tasks");

   
    $("#add-task").on("click", function () {
        const taskText = $("#new-task").val().trim();
        if (taskText === "") {
            alert("Task should not be empty!");
            return;
        }

        const taskHTML = `
            <li class="task-item">
                <span>${taskText}</span>
                <div>
                    <button class="complete">Mark Complete</button>
                    <button class="delete">Delete</button>
                </div>
            </li>
        `;

        $(taskHTML).hide().appendTo($taskList).fadeIn();
        $("#new-task").val("");
    });

    
    $taskList.on("click", ".complete", function () {
        $(this).closest("li").toggleClass("completed");
    });


    $taskList.on("click", ".delete", function () {
        $(this).closest("li").fadeOut(function () {
            $(this).remove();
        });
    });

  
    $filterTasks.on("change", function () {
        const filterValue = $(this).val();

        $taskList.children().each(function () {
            const isCompleted = $(this).hasClass("completed");

            switch (filterValue) {
                case "all":
                    $(this).show();
                    break;
                case "completed":
                    isCompleted ? $(this).show() : $(this).hide();
                    break;
                case "pending":
                    isCompleted ? $(this).hide() : $(this).show();
                    break;
            }
        });
    });
});