# Task Manager By Manthan

1. Clone the repository or download the ZIP file.
2. Extract the files to a directory.
3. Open the `index.html` file in your browser.

## Features implemented

### JavaScript
- Add tasks dynamically with validation.
- Mark tasks as completed.
- Delete tasks.

### jQuery
- Smooth fade-in effect when adding tasks.
- Smooth fade-out effect when deleting tasks.
- Filter tasks dynamically based on their status.

### Optional Features
- Edit task functionality (can be added later).